from __future__ import print_function
from __future__ import division
from __future__ import print_function

import datetime,time
import os
import tensorflow as tf
print(tf.__version__)
from tensorflow import keras
from math import log

#os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
#os.environ["CUDA_VISIBLE_DEVICES"]="0"

class CustomCallback(keras.callbacks.Callback):
	def on_train_begin(self, logs=None):
		print("Starting training; Start Time {}".format(datetime.datetime.now().time()))

	def on_train_end(self, logs=None):
		print("Stop training; End Time {}".format(datetime.datetime.now().time()))

	def on_epoch_end(self, epoch, logs=None):
		if epoch % 500 == 0:
			print("End epoch {} of training; Time: {}".format(epoch,datetime.datetime.now().time()))

def r2_sta (y_true, y_pred):
      SS_res =  K.sum(K.square(y_true - y_pred))
      SS_tot = K.sum(K.square(y_true - K.mean(y_true)))
      return (1 - SS_res/(SS_tot + K.epsilon())) 

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D
from keras import backend as K
from tensorflow.keras.callbacks import Callback,ModelCheckpoint
import numpy as np
from tensorflow.keras import Input
from tensorflow.keras.models import Model

batch_size = 4096
epochs = 5000

# ---- Load the data, already in random order ----

eos_dd2 = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax_dd2.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax..npy
mr_dd2 = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax_dd2.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax..npy

eos_ps = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax_ps.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax..npy
mr_ps = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax_ps.npy') 			#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax..npy

eos_sly = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax_sly.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax..npy
mr_sly = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax_sly.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax..npy

tr_p = np.concatenate((eos_dd2[1,:52000][:,::4],eos_ps[1,:52000][:,::4],eos_sly[1,:52000][:,::4]))
tr_m = np.concatenate((mr_dd2[0,:52000][:,::4],mr_ps[0,:52000][:,::4],mr_sly[0,:52000][:,::4]))
tr_r = np.concatenate((mr_dd2[1,:52000][:,::4],mr_ps[1,:52000][:,::4],mr_sly[1,:52000][:,::4]))

te_p = np.concatenate((eos_dd2[1,52000:][:,::4],eos_ps[1,52000:][:,::4],eos_sly[1,52000:][:,::4]))
te_m = np.concatenate((mr_dd2[0,52000:][:,::4],mr_ps[0,52000:][:,::4],mr_sly[0,52000:][:,::4]))
te_r = np.concatenate((mr_dd2[1,52000:][:,::4],mr_ps[1,52000:][:,::4],mr_sly[1,52000:][:,::4]))

print ("Max Pressure:", np.max([np.max(tr_p),np.max(te_p)]))
print ("Max Mass:", np.max([np.max(tr_m),np.max(te_m)]))
print ("Max Radius:", np.max([np.max(tr_r),np.max(te_r)]))

# ---- Normalize p, m and rad ----

tr_p = np.log(tr_p)
te_p = np.log(te_p)
minp = 0.6
tr_p = tr_p - minp
te_p = te_p - minp
maxp = 7.2
tr_p = tr_p / maxp
te_p = te_p / maxp

minm = np.min([np.min(tr_m),np.min(te_m)])
tr_m = tr_m - minm
te_m = te_m - minm
maxm = 4.
tr_m = tr_m / maxm
te_m = te_m / maxm

minr = 5.
tr_r = tr_r - minr
te_r = te_r - minr
maxr = 16.
tr_r = tr_r / maxr
te_r = te_r / maxr

# ---- Print min and max after normalizing ----

print ("Training:")
print ("Normalized Min and Max Pressure:", np.min(tr_p), np.max(tr_p))
print ("Normalized Min and Max Mass:", np.min(tr_m), np.max(tr_m))
print ("Normalized Min and Max Radius:", np.min(tr_r), np.max(tr_r))

print ("Testing:")
print ("Normalized Min and Max Pressure:", np.min(te_p), np.max(te_p))
print ("Normalized Min and Max Mass:", np.min(te_m), np.max(te_m))
print ("Normalized Min and Max Radius:", np.min(te_r), np.max(te_r))

train_p = tr_p
test_p = te_p

train_mr = np.concatenate((tr_m,tr_r),axis=1)
test_mr = np.concatenate((te_m,te_r),axis=1)

# ---- Shuffle the Data (fix random state) ----

rng_state = np.random.get_state()
np.random.shuffle(train_p)
np.random.set_state(rng_state)
np.random.shuffle(train_mr)

np.random.rand((3))

rng_state = np.random.get_state()
np.random.shuffle(test_p)
np.random.set_state(rng_state)
np.random.shuffle(test_mr)

# ---- input dimensions ----

input_len = int(test_p.shape[1])
output_len = int(test_mr.shape[1]/2.)
print("Input Length: ",input_len)
print("Output Length: ",output_len)

# ---- Print test and train shape ----

print ("Train output shape: ", np.shape(train_mr))
print ("Test output shape: ", np.shape(test_mr))

# ---- Format Input data ----

K.image_data_format() == 'channels_last'

train_p = train_p.reshape(train_p.shape[0], 1, input_len) 		# shape[0] is # of events
test_p = test_p.reshape(test_p.shape[0], 1, input_len)
train_mr = train_mr.reshape(train_mr.shape[0], 2, output_len) 		# shape[0] is # of events
test_mr = test_mr.reshape(test_mr.shape[0], 2, output_len)

input_shape = (input_len, 1)
train_p = np.transpose(train_p,(0,2,1))	
test_p = np.transpose(test_p,(0,2,1))
train_mr = np.transpose(train_mr,(0,2,1)) 	
test_mr = np.transpose(test_mr,(0,2,1))

print('Train Input shape:', train_p.shape)
print('Test Input shape:', test_p.shape)
print(train_p.shape[0], 'train samples')
print(test_p.shape[0], 'test samples')

# ---- Wavenet ----

inputA=Input(shape=(input_shape))

x = Conv1D(32,2,strides=1,padding = 'same',kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(inputA)

x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 1, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)
x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 2, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)
x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 4, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)
x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 8, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)
x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 16, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)
x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 32, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)

x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 16, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)
x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 32, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)
x = Conv1D(32,2,strides=1,padding = 'causal',dilation_rate = 64, kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='elu')(x)

x = Conv1D(2,1,strides=1,padding = 'same',kernel_initializer='he_normal', kernel_regularizer=keras.regularizers.l2(0.0000001),activation='sigmoid')(x)

model = Model(inputA, x)
print(model.summary())

tf.keras.utils.plot_model(model,to_file='wn_p_mr_r2_model_32.png',show_shapes=True)

start_time = time.time()
print("Start Time (Before compiling model):",start_time)

model.compile(optimizer=keras.optimizers.Adam(lr=0.0003),loss= 'mse', metrics=[r2_sta])

#checkpoint = ModelCheckpoint("wn_p_mr_r2_model_32.hdf5", monitor='val_loss', verbose=1, save_best_only=True, mode='auto', save_freq='epoch')
hist=model.fit(train_p,train_mr,validation_data=(test_p, test_mr), verbose=0, epochs=epochs, batch_size=batch_size,callbacks=[CustomCallback()])

print("--- %s seconds ---" % (time.time() - start_time))

model.save("wn_p_mr_r2_model_32_5k.hdf5")

# ---- Evaluate Score ----

score = model.evaluate(test_p, test_mr, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])

# ---- Predict the output from corrupted test data ----

preds = model.predict(test_p)

# ---- Save the model prediction for test data, then compare model prediction with ground truth ----

np.save('wn_p_mr_r2_graph_32_5k.npy',np.c_[preds,test_mr])

# ---- Save Training History ----

losst_hist = hist.history['loss']
lossv_hist = hist.history['val_loss']

losst_hist = np.array(losst_hist)
lossv_hist = np.array(lossv_hist)

acct_hist = hist.history['r2_sta']
accv_hist = hist.history['val_r2_sta']

acct_hist = np.array(acct_hist)
accv_hist = np.array(accv_hist)

np.savetxt('wn_p_mr_r2_acctv_32_5k.txt',np.c_[acct_hist,accv_hist])
np.savetxt('wn_p_mr_r2_losstv_32_5k.txt',np.c_[losst_hist,lossv_hist])

print ("maxm =",maxm)
print ("maxr =",maxr)
print ("minm =",minm)
print ("minr =",minr)

