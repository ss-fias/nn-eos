from __future__ import print_function
from __future__ import division
from __future__ import print_function

import numpy as np
import datetime,time
import os
from math import log
#import matplotlib
#matplotlib.use('agg')

#os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
#os.environ["CUDA_VISIBLE_DEVICES"]="0"

import tensorflow as tf
print(tf.__version__)
from tensorflow import keras
print(keras.__version__)
import keras.backend as K
K.set_image_data_format('channels_last')


from tensorflow.keras.models import Model, Sequential, load_model
from tensorflow.keras.layers import Dense, Input, Reshape, LSTM, Lambda, Conv1D
from tensorflow.keras.optimizers import Adam, Adamax
from tensorflow.keras.regularizers import l2
from tensorflow.keras.callbacks import Callback, ModelCheckpoint
from tensorflow.keras.constraints import NonNeg

rho = np.logspace(0,0.869232,128)

seed = 13
np.random.seed(seed)

def chi_sq(y_true, y_pred):
	m_term = K.mean(K.square((y_true[:,:,1] - y_pred[:,1])/mr_obs[:,2]))
	r_term = K.mean(K.square((y_true[:,:,0] - y_pred[:,0])/mr_obs[:,3]))
	return 0.5*(m_term+r_term)

def r2_sta(y_true, y_pred):
    SS_res = K.sum(K.square(y_true - y_pred))
    SS_tot = K.sum(K.square(y_true - K.mean(y_true)))
    return (1 - SS_res/(SS_tot + K.epsilon()))

def rhoc_finder(mr_128):
	#mr_128 = K.eval(mrt_128)
	m_128 = mr_128[0,:,0]
	r_128 = mr_128[0,:,1]
	m_obs = mr_obs[:,0]
	r_obs = mr_obs[:,1]
	dm_obs = 6.#*mr_obs[:,2]
	dr_obs = 1.#*mr_obs[:,3]
	
	zers = np.zeros(len(mr_obs))
	err = K.square(m_128[:,np.newaxis]-m_obs)/K.square(dm_obs)+K.square(r_128[:,np.newaxis]-r_obs)/K.square(dr_obs)
	min_idx = tf.cast(K.argmin(err,axis=0),tf.int32)

	indices = tf.stack([zers,min_idx],axis=1) 		# shape = (16,2) : indices = [[0,16],[0,32],[0,36],[0,40],[0,43],[0,46],[0,48],[0,50],...]	
	return indices

def nwrl(x,e1,p1,rho1,rho2):
	iterx = 150
	for i in range(iterx):
		f = (x-1.)*(e1/p1) - 1. -(x**2. - 2.*x)*(rho2/rho1)**(x-1.)
		df = (e1/p1) - np.log(x)*(x**2. - 2.*x)*(rho2/rho1)**(x-1.) - (rho2/rho1)**(x-1.)*(2.*x - 2.)
		x = x-f/df
	return x

def nwrl_gamma(x,divp,divp1,divr,divr1):
	iterx = 100
	for i in range(iterx):
		f = divp*(divr1/divr)**x - divp1
		df = divp*((divr1/divr)**x)*np.log(divr1/divr)
		x = x-f/df
	return x

idx = 16

# ---- Load data ----

eos_dd2 = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax_dd2.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/...npy
mr_dd2 = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax_dd2.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/...npy

eos_ps = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax_ps.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/...npy
mr_ps = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax_ps.npy') 			#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/...npy

eos_sly = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/eos_mmax_sly.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/...npy
mr_sly = np.load('/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/mr_mmax_sly.npy') 		#/home/deepthinkers/data/soma/neutronstar/mr_eos/3ml/...npy

te_p = np.concatenate((eos_dd2[1,52000:][:,::4],eos_ps[1,52000:][:,::4],eos_sly[1,52000:][:,::4]))
te_m = np.concatenate((mr_dd2[0,52000:][:,::4],mr_ps[0,52000:][:,::4],mr_sly[0,52000:][:,::4]))
te_r = np.concatenate((mr_dd2[1,52000:][:,::4],mr_ps[1,52000:][:,::4],mr_sly[1,52000:][:,::4]))
rho = rho[::4]

eos_example = eos_sly[1,4][::4]
print(eos_example.shape,eos_example)

# ---- Mock Observation ----

te_p = te_p[idx]
te_m = te_m[idx]
te_r = te_r[idx]

print(te_m,te_r)

n = 11								# n = 32 or 128

max_ind = np.argmax(te_m)					# Ensure not to use mock observations from unstable region)
print ("Number of stable masses, excluding max mass:", max_ind-1)

i = np.flatnonzero(te_m < 1.0)  				# Ensure mock observations have mass > 1 Solar mass (Normalized units = (1.0-minm)/maxm = 0.25487498293674404)
print ("Number of masses below 1 Solar Mass:", i[-1])

num_observable = len(np.arange(max_ind)[i[-1]:])
print ("Number of observable masses (after exclusion of unstable branch and masses < 1 Solar mass):", num_observable)

num_points = np.min([num_observable,n-1])
print ("Number of mock observations, including max mass:",num_points+1)

idxsobs = np.sort(np.random.choice(np.arange(max_ind)[i[-1]:],num_points,replace=False))	# Ensure mock observatins are sorted (idxsobs = [16,22,36,40,48,50,...])
idxsobs = np.append(idxsobs,max_ind)				# Ensure max mass is included 
		
mr_obs = np.zeros((num_points+1,4))
mr_obs[:,0] = te_m[idxsobs]
mr_obs[:,1] = te_r[idxsobs]
m_error = 5.0							# % error
r_error = 5.0							# % error
mr_obs[:,2] = mr_obs[:,0]*m_error*0.01					# sigma --> 5%,10%, .. (Mass)
mr_obs[:,3] = mr_obs[:,1]*r_error*0.01					# sigma --> 5%,10%,15%, .. (Radius)

print(mr_obs)

normal = np.random.normal(mr_obs[:,:2],mr_obs[:,2:],(500,len(idxsobs),2))

print (normal)

# ---- Normalize p, m and rad ----

maxp = 7.2
minp = 0.6

maxm = 4.0
maxr = 16.0
minm = 0.15901049562696065
minr = 5.0

eos_example = np.log(eos_example)
eos_example = eos_example - minp
eos_example = eos_example/maxp

mr_obs[:,0] = (mr_obs[:,0] - minm)/maxm
mr_obs[:,1] = (mr_obs[:,1] - minr)/maxr
mr_obs[:,2] = ((te_m[idxsobs]+mr_obs[:,2]-minm)/maxm) - mr_obs[:,0]
mr_obs[:,3] = ((te_r[idxsobs]+mr_obs[:,3]-minr)/maxr) - mr_obs[:,1]

te_p = np.log(te_p)
te_p = te_p - minp
te_p = te_p/maxp

te_m = te_m - minm
te_m = te_m/maxm

te_r = te_r - minr
te_r = te_r/maxr

normal[:,:,0] = normal[:,:,0] - minm
normal[:,:,0] = normal[:,:,0]/maxm

normal[:,:,1] = normal[:,:,1] - minr
normal[:,:,1] = normal[:,:,1]/maxr

#np.save("16_samples.npy",normal)
#np.save("16_mean.npy",mr_obs)

mr_obs = tf.cast(mr_obs,tf.float32)

print(normal, mr_obs)

# ---- Print min and max after normalizing ----

test_p = te_p
test_mr = np.concatenate((te_m,te_r))

# ---- input image dimensions ----

input_len = int(test_p.shape[0])
output_len = int(test_mr.shape[0]/2.)
print("Input Length: ",input_len)
print("Output Length: ",output_len)

# ---- Format Input data ----

test_p = test_p.reshape((1,1,input_len))
test_mr = test_mr.reshape((1,2, output_len))

test_p = np.transpose(test_p,(0,2,1))		
test_mr = np.transpose(test_mr,(0,2,1))

input_shape = (input_len,1)

# ---- Load your model here (Make parameters Non-trainable) ----

K.set_learning_phase(0)

model_filename = "wn_p_mr_r2_model_32.hdf5"
tovsolver_model = load_model('/home/soma/mr_eos/paper/renormalize/{0}'.format(model_filename), custom_objects={'r2_sta': r2_sta})
tovsolver = Model(tovsolver_model.input, tovsolver_model.output, name = 'TOV_Solver_Model')

tovsolver.trainable = False 
print(tovsolver.summary())

eos_example = eos_example.reshape((1,input_len))

eosstart = np.linspace(0.,0.1,input_len).reshape((-1,input_len,1)) 

# ---- Construct the fitting model for eos : input constant -->(Conv)--> eos --> (tovsolver) --> mass, radius ----

eos_start = Input(shape=(input_len,1))

eos_hidden = Conv1D(64, 1, strides=1, activation='elu', padding='same', kernel_initializer='he_normal', kernel_regularizer=l2(0.00000001), kernel_constraint=tf.keras.constraints.NonNeg())(eos_start)
eos_hidden = Conv1D(64, 1, strides=1, activation='elu', padding='same', kernel_initializer='he_normal', kernel_regularizer=l2(0.00000001), kernel_constraint=tf.keras.constraints.NonNeg())(eos_hidden)
#eos_hidden = Conv1D(64, 1, strides=1, activation='elu', padding='same', kernel_initializer='he_normal', kernel_regularizer=l2(0.00000001), kernel_constraint=tf.keras.constraints.NonNeg())(eos_hidden)
eos_hidden = Conv1D(1, 1, strides=1, activation='sigmoid', padding='same', kernel_initializer='he_normal', kernel_regularizer=l2(0.00000001), kernel_constraint=tf.keras.constraints.NonNeg())(eos_hidden)

eos_input = (eos_hidden)

mr_output = tovsolver(eos_input)
print("Output from TOV Solver model, shape:",mr_output.shape)

# ---- Assume known indices ----
'''
zers = np.zeros(len(mr_obs))
indices = tf.stack([zers,idxsobs],axis=1) 		# shape = (16,2) : indices = [[0,16],[0,32],[0,36],[0,40],[0,43],[0,46],[0,48],[0,50],...]	
indices = tf.cast(indices,tf.int32)
mrf_output = tf.gather_nd(mr_output, indices, batch_dims=0, name=None)
'''
# ---- To find Indices ----

mrf_output = tf.gather_nd(mr_output, Lambda(rhoc_finder)(mr_output), batch_dims=0, name=None)
#indices = Lambda(rhoc_finder)(mr_output)

# ---- Define the Models ----

eos_model = Model(eos_start, eos_input, name = 'EoS_Model')
mrfit_model = Model(eos_start, mrf_output, name = 'EoS-MR_fit_Model')
eos_model.summary()
mrfit_model.summary()

# ---- Compile and Fit ----

epochs1 = 1500
epochs2 = 10000
epochs3 = 15000
epochs4 = 18000	
epochs5 = 20000	
	
adm = keras.optimizers.Adam(lr=0.001)

eos_model.compile(loss='mse', optimizer=adm, metrics=[r2_sta])
mrfit_model.compile(loss=[chi_sq], optimizer=adm, metrics=[r2_sta])

reconstructed_eoss = np.zeros((len(normal),input_len))
reconstructed_mrs = np.zeros((len(normal),input_len,2))

import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.font_manager import FontProperties
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = ['Times New Roman']

fig1 = plt.figure(figsize=(10,10))
ax1 = plt.axes()
fig2 = plt.figure(figsize=(10,10))
ax2 = plt.axes()
fig3 = plt.figure(figsize=(10,10))
ax3 = plt.axes()
fig4 = plt.figure(figsize=(10,10))
ax4 = plt.axes()
for i in range(len(normal)):
	
	normal_mr = normal[i].reshape((1,len(idxsobs),2))
	eos_model.fit(eosstart,eos_example, epochs=5000)

	K.set_value(adm.lr, 0.0005)
	mrfit_model.fit(eosstart, normal_mr, epochs=epochs1)

	K.set_value(adm.lr, 0.0001)
	mrfit_model.fit(eosstart, normal_mr, epochs=epochs2)

	K.set_value(adm.lr, 0.00002)
	mrfit_model.fit(eosstart, normal_mr, epochs=epochs3)

	K.set_value(adm.lr, 0.00001)
	mrfit_model.fit(eosstart, normal_mr, epochs=epochs4)

	K.set_value(adm.lr, 0.000001)
	mrfit_model.fit(eosstart, normal_mr, epochs=epochs5)

	# ---- Compare the reconstructed EoS with ground truth ----

	eos_model.summary()

	fiteos = eos_model.predict(eosstart)
	fiteos_output = tovsolver_model.predict(fiteos)
	groundtruth_output = tovsolver_model.predict(test_p[0])		# groundtruth = test_p[0]

	fiteos = fiteos.reshape((input_len,))
	fiteos_output = fiteos_output.reshape((input_len,2))
	groundtruth_output = groundtruth_output.reshape((input_len,2))

	fiteos_output_limited = fiteos_output[idxsobs]
	groundtruth_output_limited = groundtruth_output[idxsobs]

	print(groundtruth_output.shape)
	print(fiteos_output.shape)
	print(groundtruth_output_limited.shape)
	print(fiteos_output_limited.shape)

	reconstructed_eoss[i] = np.exp((fiteos)*maxp + minp)
	reconstructed_mrs[i] = fiteos_output

	# ---- Plot output ----
	
	ax1.plot(fiteos_output[:,1]*maxr+minr,fiteos_output[:,0]*maxm+minm, c='r',alpha=0.4)
	ax1.scatter(fiteos_output_limited[:,1]*maxr+minr,fiteos_output_limited[:,0]*maxm+minm, facecolors='lightsalmon', alpha=0.7, s=70,edgecolors='r')
	ax1.plot(normal_mr[0,:,1]*maxr+minr,normal_mr[0,:,0]*maxm+minm, 'o', c='blue',alpha=0.3)
	ax3.plot(normal_mr[0,:,1]*maxr+minr,normal_mr[0,:,0]*maxm+minm, 'o', c='blue',alpha=0.3)

	ax2.plot(rho, np.exp((fiteos)*maxp + minp), '-', c='r',alpha=0.4,linewidth=2.2)
	ax4.plot(fiteos_output[:,1]*maxr+minr,fiteos_output[:,0]*maxm+minm, c='r',alpha = 0.4,linewidth=2.2)

np.save('/home/deepthinkers/data/soma/neutronstar/mr_eos/4inv/16reconstructed05_eoss_{0}11nn.npy'.format(model_filename.split('_')[0]),reconstructed_eoss)
np.save('/home/deepthinkers/data/soma/neutronstar/mr_eos/4inv/16reconstructed05_mrs_{0}11nn.npy'.format(model_filename.split('_')[0]),reconstructed_mrs)
np.save('/home/deepthinkers/data/soma/neutronstar/mr_eos/4inv/16test_eos_{0}.npy'.format(model_filename.split('_')[0]),test_p[0])
np.save('/home/deepthinkers/data/soma/neutronstar/mr_eos/4inv/16test_indices_{0}11nn.npy'.format(model_filename.split('_')[0]),idxsobs)
np.save('/home/deepthinkers/data/soma/neutronstar/mr_eos/4inv/16test_mr_{0}.npy'.format(model_filename.split('_')[0]),test_mr[0])

#ax1.plot(groundtruth_output[:,1]*maxr+minr,groundtruth_output[:,0]*maxm+minm, 'o', c='g')
ax1.plot(test_mr[0,:,1]*maxr+minr,test_mr[0,:,0]*maxm+minm,c='black',linewidth=2.5)
ax1.scatter(test_mr[0,:,1]*maxr+minr,test_mr[0,:,0]*maxm+minm,facecolors='grey', alpha=0.9,s=70, edgecolors='black')
ax1.set_ylabel('Mass (M$_{\odot}$)',fontsize=32,labelpad=15)
ax1.set_xlabel('Radius (km)',fontsize=32,labelpad=15)
ax1.tick_params(labelsize=28,pad=6)
fig1.tight_layout()
fig1.savefig('/home/soma/mr_eos/paper/inverse/16fig1_{0}_{1}_{2}_uind.png'.format(model_filename.split('_')[0],int(m_error),int(r_error)))

ax2.scatter(rho, np.exp((test_p[0])*maxp + minp), facecolors='grey', alpha=0.9, s=70, edgecolors='black')
ax2.plot(rho, np.exp((test_p[0])*maxp + minp), linewidth=2.5, c='black')
ax2.set_ylabel('Pressure (MeV/fm$^3$)',fontsize=32,labelpad=15)
ax2.set_yscale('log')
ax2.set_xlabel('Density ($\\rho_{sat}$)',fontsize=32,labelpad=15)
ax2.tick_params(labelsize=28,pad=6)
fig2.tight_layout()
fig2.savefig('/home/soma/mr_eos/paper/inverse/16fig2_{0}_{1}_{2}_uind.png'.format(model_filename.split('_')[0],int(m_error),int(r_error)))

ax3.plot(test_mr[0,:,1]*maxr+minr,test_mr[0,:,0]*maxm+minm,c='black',linewidth=2.5)
ax3.scatter(test_mr[0,:,1]*maxr+minr,test_mr[0,:,0]*maxm+minm,facecolors='grey', alpha=0.9,s=70, edgecolors='black')
ax3.set_ylabel('Mass (M$_{\odot}$)',fontsize=32,labelpad=15)
ax3.set_xlabel('Radius (km)',fontsize=32,labelpad=15)
ax3.tick_params(labelsize=28,pad=6)
fig3.tight_layout()
fig3.savefig('/home/soma/mr_eos/paper/inverse/16fig3_{0}_{1}_{2}_uind.png'.format(model_filename.split('_')[0],int(m_error),int(r_error)))

#ax4.plot(groundtruth_output[:,1]*maxr+minr,groundtruth_output[:,0]*maxm+minm, 'o', c='g')
ax4.plot(test_mr[0,:,1]*maxr+minr,test_mr[0,:,0]*maxm+minm,c='black',linewidth=2.5)
ax4.scatter(test_mr[0,:,1]*maxr+minr,test_mr[0,:,0]*maxm+minm,facecolors='grey', alpha=0.9,s=70, edgecolors='black')
ax4.set_ylabel('Mass (M$_{\odot}$)',fontsize=32,labelpad=15)
ax4.set_xlabel('Radius (km)',fontsize=32,labelpad=15)
ax4.tick_params(labelsize=28,pad=6)
fig4.tight_layout()
fig4.savefig('/home/soma/mr_eos/paper/inverse/16fig4_{0}_{1}_{2}_uind.png'.format(model_filename.split('_')[0],int(m_error),int(r_error)))

plt.show()
